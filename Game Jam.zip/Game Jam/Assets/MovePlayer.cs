﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : MonoBehaviour {


	void Start () {
		
	}
	

	void Update () {
        GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 4);

    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "Lethal")
        {
            Destroy(gameObject);
        }
    }
}
