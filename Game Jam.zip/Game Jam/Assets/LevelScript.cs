﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelScript : MonoBehaviour {

    public Transform blockSolid;
    public Transform blockPitMid;
    public Transform blockPitRight;
    public Transform blockPitLeft;
    public Transform blockGapRight;
    public Transform blockGapLeft;

    public int randNum;

    public float zScenePos = 22;
	void Start () {
       
        Instantiate(blockSolid, new Vector3(0, 0, 24), blockSolid.rotation);
        Instantiate(blockSolid, new Vector3(0, 0, 26), blockSolid.rotation);
     
    }
	
	// Update is called once per frame
	void Update () {
        
        if (zScenePos < 120)
        {
            randNum = Random.Range(0, 20);

            if (randNum == 3)
            {
                Instantiate(blockGapRight, new Vector3(0.75f, 0, zScenePos), blockGapRight.rotation);
            }

            if (randNum == 6)
            {
                Instantiate(blockGapLeft, new Vector3(-0.75f, 0, zScenePos), blockGapLeft.rotation);
            }

            if (randNum == 9)
            {
                Instantiate(blockPitMid, new Vector3(0, 0, zScenePos), blockPitMid.rotation);
            }

            if (randNum == 12)
            {
                Instantiate(blockPitLeft, new Vector3(0, 0, zScenePos), blockPitLeft.rotation);
            }

            if (randNum == 15)
            {
                Instantiate(blockPitRight, new Vector3(0, 0, zScenePos), blockPitRight.rotation);
            }
            /*
            else
            {
                Instantiate(blockSolid, new Vector3(0, 0, zScenePos), blockSolid.rotation);
            }
            */
            zScenePos += 2;
        }
        
    }
}
